
public class PilhaVaziaException extends RuntimeException {
	
	public PilhaVaziaException(String msg) {
		super(msg);
	}

}
