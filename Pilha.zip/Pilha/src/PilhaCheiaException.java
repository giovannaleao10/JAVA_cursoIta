
public class PilhaCheiaException extends RuntimeException {


	public PilhaCheiaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}