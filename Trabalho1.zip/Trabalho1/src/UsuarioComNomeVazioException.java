
public class UsuarioComNomeVazioException extends Exception {

}
