
public class UsuarioJaRegistradoException extends Exception {

}
