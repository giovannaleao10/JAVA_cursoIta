
public class Novo {
	public void registraUsuario(String nome) 
		    throws UsuarioJaRegistradoException, UsuarioComNomeVazioException, UsuarioInexistenteException {
		    if (usuarioValido(nome)) {
		        Usuario usuario = new Usuario();
		        adicionarUsuarioSeNaoExistir(usuario, nome);
		    }
		}

		private boolean usuarioValido(String nome) throws UsuarioComNomeVazioException, UsuarioInexistenteException {
		    if (nome != null) {
		        if (!nome.isEmpty()) {
		            return true;
		        } else {
		            throw new UsuarioComNomeVazioException();
		        }
		    } else {
		        throw new UsuarioInexistenteException();
		    }
		}

		private void adicionarUsuarioSeNaoExistir(Usuario usuario, String nome) throws UsuarioJaRegistradoException {
		    if (!_usuarios.contains(usuario)) {
		        _usuarios.add(usuario);
		    } else {
		        throw new UsuarioJaRegistradoException();
		    }
		}
}
