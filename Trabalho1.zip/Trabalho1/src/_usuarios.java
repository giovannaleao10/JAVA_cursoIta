
public class _usuarios {

	public static boolean contains(Usuario usuario) {
		// TODO Auto-generated method stub
		return false;
	}

	public static void add(Usuario usuario) {
		// TODO Auto-generated method stub
		
	}

}
