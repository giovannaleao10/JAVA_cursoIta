import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCustomer {
   //---->falta coisa!!
	@Test
	public void testManyRents() {
		rentMovie("Vingadores",Movie.NEW_RELEASE,2);
		rentMovie("Star_Wars",Movie.NEW_RELEASE,3);
		rentMovie("Procurando Nemo",Movie.CHILDRENS,3);
		rentMovie("Indiana Jones",Movie.REGULAR,2);
		rentMovie("Vingadores",Movie.NEW_RELEASE,2);
		String result = client.statement();
		assertContain(result,"Amount owed is 25.0");
		assertContain(result,"You earned 8 frequent renter points");
	}

	private void assertContain(String result, String content) {
		assertTrue(result.indexOf(content)>=0);
		
	}

	private void rentMovie(String title, int type, int days) {
		Movie movie = Movie.createMovie(title, type);
		Rental rent + new Rental(movie,days);
		client.addRental(rent);
		
	}

}
