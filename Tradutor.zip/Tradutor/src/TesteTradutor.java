import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;

class TesteTradutor {

	Tradutor t = new Tradutor();
	
	@Before
	public void criarTradutor(){
		Tradutor t = new Tradutor();
	}
	
	@Test
	public void tradutorSemPalavras() {
		Tradutor t = new Tradutor();
		assertTrue(t.estaVazio());
	}
	
	@Test
	public void umaTraducao() {
		Tradutor t = new Tradutor();
		t.adicionaTraducao("bom", "good");
		assertFalse(t.estaVazio());
		assertEquals("good", t.traduzir("bom"));
	}
	
	@Test
	public void duasTraducao() {
		Tradutor t = new Tradutor();
		t.adicionaTraducao("bom", "good");
		t.adicionaTraducao("mau", "bad");
		assertFalse(t.estaVazio());
		assertEquals("good", t.traduzir("bom"));
		assertEquals("bad", t.traduzir("mau"));
	}
	
	@Test
	public void duasTraducaoMesmaPalavra() {
		Tradutor t = new Tradutor();
		t.adicionaTraducao("bom", "good");
		t.adicionaTraducao("bom", "nice");
		assertFalse(t.estaVazio());
		assertEquals("good, nice", t.traduzir("bom"));
	}
	
	@Test
	public void traduzirFrase() {
		Tradutor t = new Tradutor();
		t.adicionaTraducao("guerra", "war");
		t.adicionaTraducao("é", "is");
		t.adicionaTraducao("ruim", "bad");
		assertFalse(t.estaVazio());
		assertEquals("war is bad", t.traduzirFrase("guerra é ruim"));
	}
	
	@Test
	public void traduzirFraseComDuasTraducoesMesmaPalavra() {
		Tradutor t = new Tradutor();
		t.adicionaTraducao("paz", "peace");
		t.adicionaTraducao("é", "is");
		t.adicionaTraducao("bom", "good");
		t.adicionaTraducao("bom", "nice");
		assertFalse(t.estaVazio());
		assertEquals("peace is good", t.traduzirFrase("paz é bom"));
	}
}