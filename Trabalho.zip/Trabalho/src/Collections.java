
public class Collections {

	public static List singletonList(String original) {
		// TODO Auto-generated method stub
		return null;
	}

}
