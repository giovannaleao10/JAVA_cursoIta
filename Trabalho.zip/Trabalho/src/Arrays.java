
public class Arrays {

	public static List asList(String original, String original2) {
		// TODO Auto-generated method stub
		return null;
	}

}
