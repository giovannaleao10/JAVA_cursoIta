import java.util.List;
import java.util.Collections;
import java.util.Arrays;

public class CamelCaseConverter {
    public static List<String> converterCamelCase(String original) {
        if (deveRejeitar(original)) {
            return Collections.emptyList();
        }
        return dividirCamelCase(original);
    }

    private static boolean deveRejeitar(String original) {
        return !original.matches("^[a-zA-Z0-9]*$") || Character.isDigit(original.charAt(0));
    }

    private static List<String> dividirCamelCase(String original) {
        return Arrays.asList(original.split("(?=[A-Z])|(?<=[A-Z])(?=[a-z])"));
    }
}