import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

class Teste {

    @Test
    public void converterCamelCase_Simples_DeveRetornarListaComUmaPalavra() {
        List<String> resultado = CamelCaseConverter.converterCamelCase("Nome");
        List<String> esperado = Collections.singletonList("Nome");

        assertEquals(esperado, resultado);
    }

    @Test
    public void converterCamelCase_CamelCaseSimples_DeveRetornarListaComDuasPalavras() {
        List<String> resultado = CamelCaseConverter.converterCamelCase("NomeComposto");
        List<String> esperado = Arrays.asList("Nome", "Composto");

        assertEquals(esperado, resultado);
    }
    @Test
    public void converterCamelCase_CamelCaseMisto_DeveRetornarListaComPalavrasCorretas() {
        List<String> resultado = CamelCaseConverter.converterCamelCase("NumeroCPFContribuinte");
        List<String> esperado = Arrays.asList("Numero", "CPF", "Contribuinte");

        assertEquals(esperado, resultado);
    }
    @Test
    public void converterCamelCase_ComecaComNumero_DeveRetornarListaVazia() {
        List<String> resultado = CamelCaseConverter.converterCamelCase("10Primeiros");
        assertTrue(resultado.isEmpty());
    }
}