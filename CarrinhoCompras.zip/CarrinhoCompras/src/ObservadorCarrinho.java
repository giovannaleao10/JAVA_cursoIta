
public interface ObservadorCarrinho {

	public void produtoAdicionado(String nome, int valor);
}
