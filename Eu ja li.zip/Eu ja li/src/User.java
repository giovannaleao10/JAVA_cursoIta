import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class User {
    private String username;
    private int points;
    private List<Book> booksRead;
    private Map<String, Integer> genreCount;
    private List<String> trophies;

    public User(String username) {
        this.username = username;
        this.points = 0;
        this.booksRead = new ArrayList<>();
        this.genreCount = new HashMap<>();
        this.trophies = new ArrayList<>();
    }

    public void markBookAsRead(Book book) {
        booksRead.add(book);
        points += 1 + (book.getPages() / 100);
        updateGenreCount(book.getGenre());
        checkTrophies();
    }

    private void updateGenreCount(String genre) {
        genreCount.put(genre, genreCount.getOrDefault(genre, 0) + 1);
    }

    private void checkTrophies() {
        for (String genre : genreCount.keySet()) {
            int genreBooksRead = genreCount.get(genre);
            if (genreBooksRead % 5 == 0) {
                trophies.add("Leitor de " + genre);
            }
        }
    }

    // Getters
    public String getUsername() {
        return username;
    }

    public int getPoints() {
        return points;
    }

    public List<Book> getBooksRead() {
        return booksRead;
    }

    public List<String> getTrophies() {
        return trophies;
    }
}