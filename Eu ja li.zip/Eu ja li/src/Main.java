public class Main {
    public static void main(String[] args) {
        ReadingSystem system = new ReadingSystem();

        
        User user1 = new User("User1");
        User user2 = new User("User2");
        system.addUser(user1);
        system.addUser(user2);

        Book book1 = new Book("Book1", "Author1", 120, "Fiction");
        Book book2 = new Book("Book2", "Author2", 180, "Science Fiction");
        system.addBook(book1);
        system.addBook(book2);

        
        user1.markBookAsRead(book1);
        user1.markBookAsRead(book2);

        
        system.updateRankings();

        
        System.out.println("Username: " + user1.getUsername());
        System.out.println("Points: " + user1.getPoints());
        System.out.println("Trophies: " + user1.getTrophies());

       
        System.out.println("\nRankings:");
        for (Map.Entry<String, Integer> entry : system.getRankings().entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue() + " points");
        }
    }
}