import java.util.ArrayList;
import java.util.List;

public class BookCatalog {
    private List<Book> catalog;

    public BookCatalog() {
        this.catalog = new ArrayList<>();
    }

    public void addBook(Book book) {
        catalog.add(book);
    }

    public List<Book> getCatalog() {
        return catalog;
    }
}
