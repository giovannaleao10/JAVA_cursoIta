import java.util.*;

public class ReadingSystem {
    private List<User> users;
    private List<Book> books;
    private Map<String, Integer> rankings;

    public ReadingSystem() {
        this.users = new ArrayList<>();
        this.books = new ArrayList<>();
        this.rankings = new HashMap<>();
    }

    public void addUser(User user) {
        users.add(user);
        updateRankings();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public void updateRankings() {
        users.sort(Comparator.comparingInt(User::getPoints).reversed());
        int count = Math.min(10, users.size());
        rankings.clear();
        for (int i = 0; i < count; i++) {
            rankings.put(users.get(i).getUsername(), users.get(i).getPoints());
        }
    }

    // Getters
    public Map<String, Integer> getRankings() {
        return rankings;
    }
}
