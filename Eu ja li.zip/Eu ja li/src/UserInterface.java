import java.util.Scanner;

public class UserInterface {
    private ReadingSystem system;
    private BookCatalog bookCatalog;

    public UserInterface(ReadingSystem system, BookCatalog bookCatalog) {
        this.system = system;
        this.bookCatalog = bookCatalog;
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);

        
        Book book1 = new Book("Harry Potter", "J.K. Rowling", 300, "Fantasy");
        Book book2 = new Book("Dune", "Frank Herbert", 500, "Science Fiction");
        bookCatalog.addBook(book1);
        bookCatalog.addBook(book2);

        
        User user1 = new User("Alice");
        User user2 = new User("Bob");
        system.addUser(user1);
        system.addUser(user2);

        
        System.out.println("Catálogo de Livros:");
        for (Book book : bookCatalog.getCatalog()) {
            System.out.println(book.getTitle() + " by " + book.getAuthor());
        }

       
        System.out.print("\nUsuário " + user1.getUsername() + ", digite o título do livro que você leu: ");
        String bookTitle = scanner.nextLine();

        
        Book selectedBook = findBookByTitle(bookTitle);
        if (selectedBook != null) {
            user1.markBookAsRead(selectedBook);
            System.out.println("Livro marcado como lido. Pontos atualizados.");
            System.out.println("Pontos de " + user1.getUsername() + ": " + user1.getPoints());
            System.out.println("Trophies de " + user1.getUsername() + ": " + user1.getTrophies());
        } else {
            System.out.println("Livro não encontrado no catálogo.");
        }

        
        system.updateRankings();
        System.out.println("\nRankings Atualizados:");
        for (String username : system.getRankings().keySet()) {
            System.out.println(username + ": " + system.getRankings().get(username) + " pontos");
        }
    }

    private Book findBookByTitle(String title) {
        for (Book book : bookCatalog.getCatalog()) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        ReadingSystem system = new ReadingSystem();
        BookCatalog bookCatalog = new BookCatalog();
        UserInterface userInterface = new UserInterface(system, bookCatalog);

        userInterface.run();
    }
}