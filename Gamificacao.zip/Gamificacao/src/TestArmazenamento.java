import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

public class TestArmazenamento {

    private Armazenamento armazenamento;

    @Before
    public void setUp() {
        armazenamento = new Armazenamento();
    }

    @Test
    public void testArmazenarPontos() {
        armazenamento.armazenarPontos("guerra", "estrela", 10);
        assertEquals(10, armazenamento.recuperarPontos("guerra", "estrela"));
    }

    @Test
    public void testRecuperarPontos() {
        armazenamento.armazenarPontos("guerra", "estrela", 10);
        assertEquals(10, armazenamento.recuperarPontos("guerra", "estrela"));
    }

    @Test
    public void testRecuperarUsuarios() {
        armazenamento.armazenarPontos("guerra", "estrela", 10);
        assertTrue(armazenamento.recuperarUsuarios().contains("guerra"));
    }

    @Test
    public void testRecuperarTiposPontos() {
        armazenamento.armazenarPontos("guerra", "estrela", 10);
        assertTrue(armazenamento.recuperarTiposPontos().contains("estrela"));
    }

    @Test
    public void testArmazenarMultiplosTiposDePontosParaUmUsuario() {
        armazenamento.armazenarPontos("guerra", "moeda", 5);
        armazenamento.armazenarPontos("guerra", "estrela", 10);

        assertEquals(5, armazenamento.recuperarPontos("guerra", "moeda"));
        assertEquals(10, armazenamento.recuperarPontos("guerra", "estrela"));
    }

    @Test
    public void testRecuperarPontosParaUsuarioInexistente() {
        assertEquals(0, armazenamento.recuperarPontos("usuarioInexistente", "estrela"));
    }

    @Test
    public void testRecuperarUsuariosSemPontos() {
        armazenamento.armazenarPontos("guerra", "moeda", 0);

        assertTrue(armazenamento.recuperarUsuariosSemPontos().contains("guerra"));
        assertEquals(0, armazenamento.recuperarPontos("guerra", "moeda"));
    }

    @Test
    public void testRecuperarTiposPontosSemUsuarios() {
        assertTrue(armazenamento.recuperarTiposPontos().isEmpty());
    }
}