import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import java.util.Set;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestePlacar {

    private Placar placar;
    private Armazenamento mockArmazenamento;

    @BeforeEach
    public void setUp() {
        mockArmazenamento = mock(Armazenamento.class);
        placar = new Placar(mockArmazenamento);
    }

    @Test
    public void testRegistrarTipoPonto() {
        placar.registrarTipoPonto("guerra", "estrela", 10);
        verify(mockArmazenamento).armazenarPontos("guerra", "estrela", 10);
    }

    @Test
    public void testRetornarPontosUsuario() {
        when(mockArmazenamento.recuperarPontos("guerra", "moeda")).thenReturn(20);
        when(mockArmazenamento.recuperarPontos("guerra", "estrela")).thenReturn(25);

        assertEquals(20, placar.retornarPontosUsuario("guerra", "moeda"));
        assertEquals(25, placar.retornarPontosUsuario("guerra", "estrela"));
        assertEquals(0, placar.retornarPontosUsuario("guerra", "energia"));
    }

    @Test
    public void testRetornarRankingTipoPonto() {
        when(mockArmazenamento.recuperarUsuarios()).thenReturn(Set.of("guerra", "fernandes", "rodrigo"));
        when(mockArmazenamento.recuperarPontos("guerra", "estrela")).thenReturn(25);
        when(mockArmazenamento.recuperarPontos("fernandes", "estrela")).thenReturn(19);
        when(mockArmazenamento.recuperarPontos("rodrigo", "estrela")).thenReturn(17);

        assertEquals("guerra", placar.retornarRankingTipoPonto("estrela").get(0));
        assertEquals("fernandes", placar.retornarRankingTipoPonto("estrela").get(1));
        assertEquals("rodrigo", placar.retornarRankingTipoPonto("estrela").get(2));
    }

    @Test
    public void testRetornarUsuariosSemPontos() {
        when(mockArmazenamento.recuperarUsuarios()).thenReturn(Set.of("guerra", "fernandes", "rodrigo"));
        when(mockArmazenamento.recuperarPontos("guerra", "estrela")).thenReturn(0);
        when(mockArmazenamento.recuperarPontos("fernandes", "estrela")).thenReturn(0);
        when(mockArmazenamento.recuperarPontos("rodrigo", "estrela")).thenReturn(0);

        assertTrue(placar.retornarUsuariosSemPontos().contains("guerra"));
        assertTrue(placar.retornarUsuariosSemPontos().contains("fernandes"));
        assertTrue(placar.retornarUsuariosSemPontos().contains("rodrigo"));
    }

    @Test
    public void testRetornarTiposPontosParaUsuario() {
        when(mockArmazenamento.recuperarTiposPontos()).thenReturn(Set.of("moeda", "estrela", "energia"));

        assertEquals(Set.of("moeda", "estrela", "energia"), placar.retornarTiposPontosParaUsuario("guerra"));
    }
}