import java.io.*;
import java.util.*;

public class Armazenamento {
    private Map<String, Map<String, Integer>> dados;
    private static final String ARQUIVO_DADOS = "dados.csv";

    public Armazenamento() {
        this.dados = new HashMap<>();
        carregarDoArquivo();
    }

    public void armazenarPontos(String usuario, String tipoPonto, int quantidade) {
        dados.computeIfAbsent(usuario, k -> new HashMap<>());
        Map<String, Integer> pontosUsuario = dados.get(usuario);
        pontosUsuario.put(tipoPonto, quantidade);
        salvarNoArquivo();
    }

    public int recuperarPontos(String usuario, String tipoPonto) {
        return dados.getOrDefault(usuario, Collections.emptyMap())
                .getOrDefault(tipoPonto, 0);
    }

    public Set<String> recuperarUsuarios() {
        return dados.keySet();
    }

    public Set<String> recuperarTiposPontos() {
        Set<String> tiposPontos = new HashSet<>();
        for (Map<String, Integer> pontosUsuario : dados.values()) {
            tiposPontos.addAll(pontosUsuario.keySet());
        }
        return tiposPontos;
    }

    private void salvarNoArquivo() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(ARQUIVO_DADOS))) {
            for (Map.Entry<String, Map<String, Integer>> entry : dados.entrySet()) {
                String usuario = entry.getKey();
                Map<String, Integer> pontosUsuario = entry.getValue();
                for (Map.Entry<String, Integer> pontoEntry : pontosUsuario.entrySet()) {
                    String tipoPonto = pontoEntry.getKey();
                    int quantidade = pontoEntry.getValue();
                    writer.println(usuario + "," + tipoPonto + "," + quantidade);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void carregarDoArquivo() {
        try (BufferedReader reader = new BufferedReader(new FileReader(ARQUIVO_DADOS))) {
            String linha;
            while ((linha = reader.readLine()) != null) {
                String[] partes = linha.split(",");
                if (partes.length == 3) { // Check if the line has all necessary parts
                    String usuario = partes[0];
                    String tipoPonto = partes[1];
                    int quantidade = Integer.parseInt(partes[2]);

                    dados.computeIfAbsent(usuario, k -> new HashMap<>());
                    Map<String, Integer> pontosUsuario = dados.get(usuario);
                    pontosUsuario.put(tipoPonto, quantidade);
                } else {
                    System.err.println("Ignored invalid line: " + Arrays.toString(partes));
                }
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

	public Set<String> recuperarTiposPontosParaUsuario(String usuario) {
		return null;
	}

	public Set<String> recuperarUsuariosSemPontos() {
		return null;
	}
}