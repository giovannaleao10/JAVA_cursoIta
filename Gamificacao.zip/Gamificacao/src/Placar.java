import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Placar {
    private Armazenamento armazenamento;

    public Placar(Armazenamento armazenamento) {
        this.armazenamento = armazenamento;
    }

    public void registrarTipoPonto(String usuario, String tipoPonto, int quantidade) {
        armazenamento.armazenarPontos(usuario, tipoPonto, quantidade);
    }

    public int retornarPontosUsuario(String usuario, String tipoPonto) {
        return armazenamento.recuperarPontos(usuario, tipoPonto);
    }

    public List<String> retornarRankingTipoPonto(String tipoPonto) {
        Set<String> usuarios = armazenamento.recuperarUsuarios();
        List<String> ranking = new ArrayList<>();

        for (String usuario : usuarios) {
            int pontos = armazenamento.recuperarPontos(usuario, tipoPonto);
            if (pontos > 0) {
                ranking.add(usuario);
            }
        }

        ranking.sort(Comparator.comparingInt(usuario -> -armazenamento.recuperarPontos(usuario, tipoPonto)));
        return ranking;
    }

    public Set<String> retornarUsuariosSemPontos() {
        Set<String> usuarios = armazenamento.recuperarUsuarios();
        Set<String> usuariosSemPontos = new HashSet<>();

        for (String usuario : usuarios) {
            boolean temPontos = false;
            Set<String> tiposPontos = armazenamento.recuperarTiposPontosParaUsuario(usuario);

            for (String tipoPonto : tiposPontos) {
                if (armazenamento.recuperarPontos(usuario, tipoPonto) > 0) {
                    temPontos = true;
                    break;
                }
            }

            if (!temPontos) {
                usuariosSemPontos.add(usuario);
            }
        }

        return usuariosSemPontos;
    }

    public Set<String> retornarTiposPontosParaUsuario(String usuario) {
        return armazenamento.recuperarTiposPontosParaUsuario(usuario);
    }
}